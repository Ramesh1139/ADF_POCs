package com.nordstrom.rpm.comboboxImpl;

public interface DropdownDataItem 
{
    public String getId();
    public String getDescription();
}
