package com.nordstrom.auth;

public class ApplicationType{
public enum ApplicationSelection {
    RPM,
    SIM,
    ReIB,
    RMS
        //private static final long serialVersionUID = 0L;
    }
}
