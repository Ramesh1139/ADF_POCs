package com.nordstrom.rpm.comboboxImpl;

public interface DropdownSelectionListener 
{
    public void valueSelected(DropdownDataItem selectedItem);
}
